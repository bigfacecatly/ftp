.. pyftpdlib documentation master file, created by
   sphinx-quickstart on Sat Apr 12 12:12:58 2014.
   You can adapt this file completely to your liking, but it should at least
   contain the root `toctree` directive.

====================================
Welcome to pyftpdlib's documentation
====================================

If you're in a hurry just skip to the `Tutorial <tutorial.html>`__.

.. toctree::
    :maxdepth: 2

    install
    tutorial
    api
    faqs
    benchmarks
    rfc-compliance
    adoptions

Indices and tables
==================

* :ref:`genindex`
* :ref:`search`
